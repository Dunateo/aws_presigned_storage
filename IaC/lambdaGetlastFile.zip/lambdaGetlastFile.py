import boto3
import os
from botocore.exceptions import ClientError

def lambda_handler(event, context):
    s3_client = boto3.client('s3')
    #bucket_name = 'pag-bucket'
    bucket_name = os.environ['BUCKET_NAME']

    try:
        # Obtenir la liste des objets triés par date de modification
        response = s3_client.list_objects_v2(Bucket=bucket_name)

        sorted_objects = sorted(response.get('Contents', []), 
                                key=lambda x: x['LastModified'], 
                                reverse=True)

        if not sorted_objects:
            return {
                'statusCode': 404,
                'body': 'Aucun fichier trouvé dans le bucket'
            }

        # Récupérer la clé du fichier le plus récent
        latest_file_key = sorted_objects[0]['Key']

        # Générer l'URL présignée
        presigned_url = s3_client.generate_presigned_url('get_object',
            Params={'Bucket': bucket_name, 'Key': latest_file_key},
            ExpiresIn=3600  # URL valide pendant 1 heure
        )

        return {
            'statusCode': 200,
            'body': presigned_url
        }
    except ClientError as e:
        return {
            'statusCode': 500,
            'body': str(e)
        }
